package mk.ukim.finki.wpaud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WpAudApplicationTests {

	@Test
	void contextLoads() {
	}

}
