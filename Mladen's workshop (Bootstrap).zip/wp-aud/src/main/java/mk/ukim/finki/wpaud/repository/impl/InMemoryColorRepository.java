package mk.ukim.finki.wpaud.repository.impl;

import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.Color;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class InMemoryColorRepository {
    public Color save(Color c) {
        DataHolder.colors.add(c);
        return c;
    }

    public List<Color> findAll() {
        return DataHolder.colors;
    }
    public void deleteById(Long id) {
        DataHolder.colors.removeIf(i->i.getId().equals(id));
    }
}
