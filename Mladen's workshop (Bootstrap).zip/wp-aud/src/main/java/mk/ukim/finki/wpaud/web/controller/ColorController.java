package mk.ukim.finki.wpaud.web.controller;

import mk.ukim.finki.wpaud.model.Color;
import mk.ukim.finki.wpaud.service.ColorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/colorcontroller")
public class ColorController {
    private final ColorService colorService;

    public ColorController(ColorService colorService) {
        this.colorService = colorService;
    }

    @GetMapping
    public String getColorPage(Model model) {
        model.addAttribute("colors", colorService.listColors());
        return "color";
    }

    @PostMapping
    public String addColorPage(@RequestParam Color color, Model model) {
        colorService.save(color);
        return "redirect:/colorcontroller";
    }

    @GetMapping("/colorpage")
    public String colorpage() {
        return "addcolor";
    }

    @DeleteMapping("/deletecolor/{id}")
    public String deleteColor(@PathVariable Long id) {
        colorService.deleteById(id);
        return "redirect:/colorcontroller";
    }
}
