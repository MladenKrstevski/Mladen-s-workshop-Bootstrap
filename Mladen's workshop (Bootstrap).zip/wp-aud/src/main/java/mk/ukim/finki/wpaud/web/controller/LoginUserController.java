package mk.ukim.finki.wpaud.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wpaud.model.User;
import mk.ukim.finki.wpaud.service.AuthService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/loginuser")
public class LoginUserController {

    private final AuthService authService;

    public LoginUserController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping
    private String getUserLoginPage() {
        return "loginuser";
    }

    @PostMapping
    public String postUserLoginPage(@RequestParam String name,
                                    @RequestParam String password,
                                    HttpServletRequest req,
                                    Model model) {

        User user = null;

        try {
            user = authService.login(name, password);
            req.getSession().setAttribute("user", user);
            return "redirect:/productslist";
        } catch (RuntimeException ex) {
            return "loginuser";
        }
    }
}
