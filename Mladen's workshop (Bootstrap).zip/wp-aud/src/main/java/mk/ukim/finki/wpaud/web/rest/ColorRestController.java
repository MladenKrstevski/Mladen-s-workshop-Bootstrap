package mk.ukim.finki.wpaud.web.rest;

import mk.ukim.finki.wpaud.model.Color;
import mk.ukim.finki.wpaud.model.Product;
import mk.ukim.finki.wpaud.model.dto.ProductDto;
import mk.ukim.finki.wpaud.service.ColorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/api/colors")
public class ColorRestController {

    private final ColorService colorService;

    public ColorRestController(ColorService colorService) {
        this.colorService = colorService;
    }

    @GetMapping
    private List<Color> findAll() {
        return this.colorService.listColors();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Color> findById(@PathVariable Long id) {
        return this.colorService.findById(id)
                .map(color -> ResponseEntity.ok().body(color))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public ResponseEntity<Color> save(@RequestBody Color color) {
        return this.colorService.save(color)
                .map(c -> ResponseEntity.ok().body(c))
                .orElseGet(() -> ResponseEntity.badRequest().build());
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Color> save(@PathVariable Long id, @RequestBody Color color) {
        return this.colorService.edit(id, color)
                .map(c -> ResponseEntity.ok().body(c))
                .orElseGet(() -> ResponseEntity.badRequest().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteById(@PathVariable Long id) {
        this.colorService.deleteById(id);
        if(this.colorService.findById(id).isEmpty()) return ResponseEntity.ok().build();
        return ResponseEntity.badRequest().build();
    }
}
