package mk.ukim.finki.wpaud.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.*;
import mk.ukim.finki.wpaud.service.AnimalService;
import mk.ukim.finki.wpaud.service.PettingZooService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/animalcontroller")
public class AnimalController {

    private final AnimalService animalService;
    private final PettingZooService pettingZooService;

    public AnimalController(AnimalService animalService, PettingZooService pettingZooService) {
        this.animalService = animalService;
        this.pettingZooService = pettingZooService;
    }

    @GetMapping
    public String getAnimalPage(HttpServletRequest req, Model model) {
        req.getSession().setAttribute("person", DataHolder.persons.get(0));
        List<Animal> animals = animalService.listAnimals();
        model.addAttribute("animals", animals);
        return "animal";
    }

    @PostMapping("/{id}")
    public String addAnimalToPettingZoo(@PathVariable Long id, HttpServletRequest req) {
        Animal a = animalService.findById(id).get();
        Person p = (Person)req.getSession().getAttribute("person");
        PettingZoo pz = pettingZooService.findByPerson(p.getId()).get();
        pettingZooService.addAnimalToPettingZoo(p.getId(), a.getId());
        req.getSession().setAttribute("animals", pettingZooService.listAllAnimalsInPettingZoo(pz.getId()));
        return "redirect:/pettingzoocontroller";
    }
}
