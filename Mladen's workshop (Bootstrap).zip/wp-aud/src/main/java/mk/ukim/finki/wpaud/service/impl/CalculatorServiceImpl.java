package mk.ukim.finki.wpaud.service.impl;

import mk.ukim.finki.wpaud.model.Numbers;
import mk.ukim.finki.wpaud.repository.impl.InMemoryCalculatorRepository;
import mk.ukim.finki.wpaud.service.CalculatorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalculatorServiceImpl implements CalculatorService {

    private final InMemoryCalculatorRepository calculatorRepository;

    public CalculatorServiceImpl(InMemoryCalculatorRepository calculatorRepository) {
        this.calculatorRepository = calculatorRepository;
    }

    @Override
    public int addition(int a, int b) {
        return 0;
    }

    @Override
    public int subtraction(int a, int b) {
        return 0;
    }

    @Override
    public int multiplication(int a, int b) {
        return 0;
    }

    @Override
    public int division(int a, int b) {
        return 0;
    }

    @Override
    public List<Numbers> listNumbers() {
        return calculatorRepository.findAll();
    }

    @Override
    public Numbers save(int a, int b) {
        Numbers c = new Numbers(a, b);
        calculatorRepository.save(c);
        return c;
    }
}
