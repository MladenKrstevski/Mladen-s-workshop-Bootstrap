package mk.ukim.finki.wpaud.repository.impl;

import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.Person;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class InMemoryPersonRepository {
    public Person save(Person p) {
        DataHolder.persons.add(p);
        return p;
    }

    public List<Person> listPersons() {
        return DataHolder.persons;
    }

    public Optional<Person> findById(Long id) {
        return DataHolder.persons.stream().filter(i->i.getId().equals(id)).findFirst();
    }
}
