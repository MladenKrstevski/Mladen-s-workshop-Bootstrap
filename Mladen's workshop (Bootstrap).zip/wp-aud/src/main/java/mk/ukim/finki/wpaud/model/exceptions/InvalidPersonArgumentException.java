package mk.ukim.finki.wpaud.model.exceptions;

public class InvalidPersonArgumentException extends RuntimeException {
    public InvalidPersonArgumentException(String message) {
        super(message);
    }
}
