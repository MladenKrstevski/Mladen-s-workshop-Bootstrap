package mk.ukim.finki.wpaud.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wpaud.model.Person;
import mk.ukim.finki.wpaud.model.Product;
import mk.ukim.finki.wpaud.model.exceptions.InvalidPersonArgumentException;
import mk.ukim.finki.wpaud.service.PersonService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/personcontroller")
public class PersonController {
    private final PersonService personService;

    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    @GetMapping
    public String hello(Model model) {
        List<Person> persons = personService.listPersons();
        model.addAttribute("persons", persons);
        return "personcontroller";
    }

    @PostMapping
    public String personName(@RequestParam String name,
                             @RequestParam String lastname,
                             Model model) {

        try {
            personService.create(name, lastname);
            return "redirect:/personcontroller";
        } catch(InvalidPersonArgumentException exception) {
            List<Person> persons = personService.listPersons();
            model.addAttribute("persons", persons);
            model.addAttribute("hasError", true);
            model.addAttribute("error", exception.getMessage());
            return "personcontroller";
        }
    }
}
