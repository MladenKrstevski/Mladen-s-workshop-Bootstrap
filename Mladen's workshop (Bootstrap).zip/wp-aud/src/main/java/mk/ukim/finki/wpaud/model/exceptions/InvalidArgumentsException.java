package mk.ukim.finki.wpaud.model.exceptions;

public class InvalidArgumentsException extends RuntimeException {

    public InvalidArgumentsException() {
        super("Invalid argument exception.");
    }
}
