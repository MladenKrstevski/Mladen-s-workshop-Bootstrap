package mk.ukim.finki.wpaud.repository.impl;

import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.Category;
import mk.ukim.finki.wpaud.model.Numbers;
import org.springframework.stereotype.Repository;

import java.util.*;
@Repository
public class InMemoryCalculatorRepository {
    public List<Numbers> findAll() {return DataHolder.numbers;}

    public Numbers save(Numbers n) {
        DataHolder.numbers.add(n);
        return n;
    }
}