package mk.ukim.finki.wpaud.config;

import lombok.AllArgsConstructor;
import mk.ukim.finki.wpaud.config.filters.JWTAuthenticationFilter;
import mk.ukim.finki.wpaud.config.filters.JWTAuthorizationFilter;
import mk.ukim.finki.wpaud.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Profile("jwt")
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
@Order(200)

public class JWTWebSecurityConfig{

    private final PasswordEncoder passwordEncoder;
    private final UserService userService;
    final AuthenticationConfiguration authenticationConfiguration;


    public JWTWebSecurityConfig(PasswordEncoder passwordEncoder, UserService userService, AuthenticationConfiguration authenticationConfiguration) {
        this.passwordEncoder = passwordEncoder;
        this.userService = userService;
        this.authenticationConfiguration = authenticationConfiguration;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        //authenticationManager = http.getSharedObject(AuthenticationManager.class);

        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(
                        authorizeRequests->
                                authorizeRequests

                                        .requestMatchers("/", "/home", "/products", "/api/login","/api/products", "/register", "/login").permitAll()
                                        .requestMatchers("/admin/**").hasRole("ADMIN")
                                        .anyRequest()
                                        .authenticated())
            //.sessionManagement(sessionManagement->sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                .formLogin(form -> form.loginPage("/login").permitAll()
                        .failureUrl("/login?error=BadCredentials").defaultSuccessUrl("/home"))
                .logout(logout -> logout.logoutUrl("/logout")
                        .clearAuthentication(true)
                        .invalidateHttpSession(true)
                        .deleteCookies("e-shop")
                        .logoutSuccessUrl("/login")
                );
        http.cors(Customizer.withDefaults());

        //http.apply(new MyCustomDsl(passwordEncoder, userService));
        return http.build();


    }



    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
}
