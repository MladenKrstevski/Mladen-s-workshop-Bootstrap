package mk.ukim.finki.wpaud.service.impl;

import mk.ukim.finki.wpaud.model.Animal;
import mk.ukim.finki.wpaud.model.Person;
import mk.ukim.finki.wpaud.model.PettingZoo;
import mk.ukim.finki.wpaud.repository.impl.InMemoryAnimalRepository;
import mk.ukim.finki.wpaud.repository.impl.InMemoryPersonRepository;
import mk.ukim.finki.wpaud.repository.impl.InMemoryPettingZooRepository;
import mk.ukim.finki.wpaud.service.PettingZooService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PettingZooServiceImpl implements PettingZooService {
    private final InMemoryPettingZooRepository inMemoryPettingZooRepository;
    private final InMemoryPersonRepository inMemoryPersonRepository;
    private final InMemoryAnimalRepository inMemoryAnimalRepository;

    public PettingZooServiceImpl(InMemoryPettingZooRepository inMemoryPettingZooRepository, InMemoryPersonRepository inMemoryPersonRepository, InMemoryAnimalRepository inMemoryAnimalRepository) {
        this.inMemoryPettingZooRepository = inMemoryPettingZooRepository;
        this.inMemoryPersonRepository = inMemoryPersonRepository;
        this.inMemoryAnimalRepository = inMemoryAnimalRepository;
    }

    @Override
    public Optional<PettingZoo> findById(Long id) {
        return inMemoryPettingZooRepository.findById(id);
    }

    @Override
    public List<Animal> listAllAnimalsInPettingZoo(Long id) {
        PettingZoo pz = findById(id).get();
        return pz.getAnimals();
    }

    @Override
    public void addAnimalToPettingZoo(Long personID, Long animalID) {
        Animal a = inMemoryAnimalRepository.findById(animalID).get();
        PettingZoo pz = findByPerson(personID).get();
        pz.getAnimals().add(a);
    }

    @Override
    public Optional<PettingZoo> findByPerson(Long personID) {
        Person p = inMemoryPersonRepository.findById(personID).get();
        return inMemoryPettingZooRepository.findByPerson(p);
    }
}
