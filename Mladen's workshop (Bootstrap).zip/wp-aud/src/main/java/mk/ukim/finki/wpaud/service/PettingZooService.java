package mk.ukim.finki.wpaud.service;

import mk.ukim.finki.wpaud.model.Animal;
import mk.ukim.finki.wpaud.model.PettingZoo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface PettingZooService {
    Optional<PettingZoo> findById(Long id);
    List<Animal> listAllAnimalsInPettingZoo(Long id);

    public void addAnimalToPettingZoo(Long personID, Long animalID);

    public Optional<PettingZoo> findByPerson (Long personID);
}