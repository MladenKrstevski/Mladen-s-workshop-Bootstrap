package mk.ukim.finki.wpaud.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wpaud.model.Product;
import mk.ukim.finki.wpaud.model.ShoppingCart;
import mk.ukim.finki.wpaud.model.User;
import mk.ukim.finki.wpaud.service.CategoryService;
import mk.ukim.finki.wpaud.service.ManufacturerService;
import mk.ukim.finki.wpaud.service.ProductService;
import mk.ukim.finki.wpaud.service.ShoppingCartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/productslist")
public class ProductsListController {

    private final ProductService productService;
    private final CategoryService categoryService;
    private final ManufacturerService manufacturerService;
    private final ShoppingCartService shoppingCartService;

    public ProductsListController(ProductService productService, CategoryService categoryService, ManufacturerService manufacturerService, ShoppingCartService shoppingCartService) {
        this.productService = productService;
        this.categoryService = categoryService;
        this.manufacturerService = manufacturerService;
        this.shoppingCartService = shoppingCartService;
    }

    @GetMapping
    public String getProductsPage(Model model) {
        List<Product> products = productService.findAll();
        products.sort((a, b) -> a.getName().compareTo(b.getName()));
        model.addAttribute("products", products);
        return "productslist";
    }

    @GetMapping("/add-product")
    public String addProductsPage(Model model) {
        model.addAttribute("categories", categoryService.listCategories());
        model.addAttribute("manufacturers", manufacturerService.findAll());
        return "addproducts";
    }

    @PostMapping("/saveproduct")
    public String saveProduct(@RequestParam String name,
                              @RequestParam Double price,
                              @RequestParam Integer quantity,
                              @RequestParam Long category,
                              @RequestParam Long manufacturer,
                              @RequestParam String imageUrl,
                              Model model) {
        productService.save(name, price, quantity, category, manufacturer, imageUrl);
        return "redirect:/productslist";
    }

    @DeleteMapping("/deleteproduct/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteById(id);
        return "redirect:/productslist";
    }

    @GetMapping("/editproduct/{id}")
    public String editProduct(@PathVariable Long id, Model model) {
        Product p = productService.findById(id).get();
        model.addAttribute("product", p);
        model.addAttribute("categories", categoryService.listCategories());
        model.addAttribute("manufacturers", manufacturerService.findAll());
        return "addproducts";
    }

    @GetMapping("/addproducttocart/{id}")
    public String addProductToCart(@PathVariable Long id, HttpServletRequest req, Model model) {
        Product p = productService.findById(id).get();
        model.addAttribute("product", p);

        User user = (User)req.getSession().getAttribute("user");
        shoppingCartService.addProductToShoppingCart(user.getUsername(), p.getId());
        ShoppingCart shoppingCart = shoppingCartService.getActiveShoppingCart(user.getUsername());
        model.addAttribute("productslist", shoppingCartService.listAllProductsInShoppingCart(shoppingCart.getId()));
        return "addproducttocart";
    }
}
