package mk.ukim.finki.wpaud.config;

import mk.ukim.finki.wpaud.config.filters.JWTAuthenticationFilter;
import mk.ukim.finki.wpaud.config.filters.JWTAuthorizationFilter;
import mk.ukim.finki.wpaud.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Profile("session")
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
public class WebSecurityConfig {

    private final PasswordEncoder passwordEncoder;
    private final UserService userService;
    private final AuthenticationManagerBuilder authManagerBuilder;

    public WebSecurityConfig(PasswordEncoder passwordEncoder,  UserService userService, AuthenticationManagerBuilder authManagerBuilder) {
        this.passwordEncoder = passwordEncoder;
        this.userService = userService;
        this.authManagerBuilder = authManagerBuilder;
    }
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {


        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(
                        authorizeRequests->
                                authorizeRequests

                                        .requestMatchers("/", "/home", "/products", "/api/products", "/api/login", "/register", "/login").permitAll()
                                        .requestMatchers("/admin/**").hasRole("ADMIN")
                                        .anyRequest()
                                        .authenticated())
                //.formLogin(form -> form.loginPage("/login").permitAll()
                //        .failureUrl("/login?error=BadCredentials").defaultSuccessUrl("/home"))

                .addFilter(authenticationFilter(http))
                .addFilter(authorizationFilter(http))
/*logout(logout -> logout.logoutUrl("/logout")
                        .clearAuthentication(true)
                        .invalidateHttpSession(true)
                        .deleteCookies("e-shop")
                        .logoutSuccessUrl("/login")
                )*/
                .sessionManagement(sessionManagement->sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

        ;
        //http.apply(new MyCustomDsl(passwordEncoder, userService));

        http.cors(Customizer.withDefaults());
        return http.build();


    }

    /*
    @Bean
    public InMemoryUserDetailsManager userDetailsService(AuthenticationManagerBuilder auth) {

        //return auth.authenticationProvider(customUsernamePasswordAuthenticationProvider);

        // User.UserBuilder users = User.withDefaultPasswordEncoder();
        UserDetails user = User.builder()
                .username("mk")
                .password(passwordEncoder.encode("mk"))
                .roles("USER")
                .build();

        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder.encode("admin"))
                .roles("ADMIN")
                .build();

        return new InMemoryUserDetailsManager(user, admin);
    }
*/
    @Bean
    public JWTAuthorizationFilter authorizationFilter(HttpSecurity http) throws Exception {
        return new JWTAuthorizationFilter(authenticationManager(http.getSharedObject(AuthenticationConfiguration.class)), userService);
    }

    @Bean
    public JWTAuthenticationFilter authenticationFilter(HttpSecurity http) throws Exception {
        return new JWTAuthenticationFilter(authenticationManager(http.getSharedObject(AuthenticationConfiguration.class)), userService, passwordEncoder);
    }
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }



}