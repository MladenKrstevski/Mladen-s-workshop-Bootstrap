package mk.ukim.finki.wpaud.model.enumerations;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}
