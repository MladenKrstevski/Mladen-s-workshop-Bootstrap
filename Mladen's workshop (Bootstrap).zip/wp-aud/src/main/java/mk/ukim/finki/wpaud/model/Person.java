package mk.ukim.finki.wpaud.model;

public class Person {
    String name;
    String lastname;
    Long id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person(String name, String lastname) {
        this.id = (long)(Math.random() * 1000);
        this.name = name;
        this.lastname = lastname;
    }
}
