package mk.ukim.finki.wpaud.bootstrap;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import mk.ukim.finki.wpaud.model.*;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@Getter
public class DataHolder {
    public static List<Category> categories = new ArrayList<>();

    public static List<Numbers> numbers = new ArrayList<>();

    public static List<Person> persons = new ArrayList<>();

    public static List<User> users = new ArrayList<>();
    public static List<Manufacturer> manufacturers = new ArrayList<>();
    public static List<Product> products = new ArrayList<>();
    public static List<ShoppingCart> shoppingCarts = new ArrayList<>();

    public static List<Animal> animals = new ArrayList<>();
    public static List<PettingZoo> pettingZoos = new ArrayList<>();

    public static List<Color> colors = new ArrayList<>();


    @PostConstruct
    public void init() {
        Person a = new Person("Mladen", "Krstevski");
        Person b = new Person("Philip", "Krstevski");
        Person c = new Person("Zvonko", "Krstevski");
        persons.add(a);
        persons.add(b);
        persons.add(c);
        Manufacturer manufacturer = new Manufacturer("Mladen", "VM21/2/28");
        manufacturers.add(manufacturer);
        Category category = new Category("Sport", "Sport category");
        categories.add(category);
        animals.add(new Animal("Dog"));
        animals.add(new Animal("Cat"));
        animals.add(new Animal("Parrot"));
        animals.add(new Animal("Rabbit"));
        pettingZoos.add(new PettingZoo(a));
        pettingZoos.add(new PettingZoo(b));
        pettingZoos.add(new PettingZoo(c));
        colors.add(new Color("Blue"));
        colors.add(new Color("Red"));
        colors.add(new Color("Green"));
        colors.add(new Color("Yellow"));
        colors.add(new Color("Orange"));
    }
}
