package mk.ukim.finki.wpaud.model;

import java.util.ArrayList;
import java.util.List;

public class PettingZoo {
    Long id;
    Person p;
    List<Animal> animals;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person getP() {
        return p;
    }

    public void setP(Person p) {
        this.p = p;
    }

    public List<Animal> getAnimals() {
        return animals;
    }

    public void setAnimals(List<Animal> animals) {
        this.animals = animals;
    }

    public PettingZoo(Person p) {
        this.id = (long)(Math.random() * 1000);
        this.p = p;
        this.animals = new ArrayList<>();
    }
}
