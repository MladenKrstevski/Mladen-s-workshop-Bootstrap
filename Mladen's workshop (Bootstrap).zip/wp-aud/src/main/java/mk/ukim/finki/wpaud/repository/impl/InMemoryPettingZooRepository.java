package mk.ukim.finki.wpaud.repository.impl;

import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.Person;
import mk.ukim.finki.wpaud.model.PettingZoo;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class InMemoryPettingZooRepository {

    public Optional<PettingZoo> findById(Long id) {
        return DataHolder.pettingZoos.stream().filter
                (i->i.getId().equals(id)).findFirst();
    }

    public Optional<PettingZoo> findByPerson(Person p) {
        return DataHolder.pettingZoos.stream().filter
                (i->i.getP().equals(p)).findFirst();
    }
}
