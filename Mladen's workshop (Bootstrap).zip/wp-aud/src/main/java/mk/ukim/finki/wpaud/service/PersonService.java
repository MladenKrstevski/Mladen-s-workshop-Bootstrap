package mk.ukim.finki.wpaud.service;

import mk.ukim.finki.wpaud.model.Person;

import java.util.List;
import java.util.Optional;

public interface PersonService {

    Person create(String name, String lastname);
    List<Person> listPersons();

    Optional<Person> findById(Long id);
}
