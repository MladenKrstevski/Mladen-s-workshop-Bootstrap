package mk.ukim.finki.wpaud.service;

import mk.ukim.finki.wpaud.model.Numbers;

import java.util.List;

public interface CalculatorService {
    int addition(int a, int b);
    int subtraction(int a, int b);
    int multiplication(int a, int b);
    int division(int a, int b);
    List<Numbers> listNumbers ();
    Numbers save(int a, int b);
}
