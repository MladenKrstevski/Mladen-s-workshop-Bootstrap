package mk.ukim.finki.wpaud.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/welcomeuser")
public class WelcomeUserController {
    @GetMapping
    public String getWelcomePage() {
        return "welcome";
    }
}
