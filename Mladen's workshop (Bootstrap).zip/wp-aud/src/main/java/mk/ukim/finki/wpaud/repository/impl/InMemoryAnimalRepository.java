package mk.ukim.finki.wpaud.repository.impl;

import mk.ukim.finki.wpaud.bootstrap.DataHolder;
import mk.ukim.finki.wpaud.model.Animal;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class InMemoryAnimalRepository {
    public Animal save(Animal a) {
        DataHolder.animals.add(a);
        return a;
    }

    public List<Animal> findAll() {
        return DataHolder.animals;
    }

    public Optional<Animal> findById(Long id) {
        return DataHolder.animals.stream().filter(i->i.getId().equals(id)).findFirst();
    }
}
