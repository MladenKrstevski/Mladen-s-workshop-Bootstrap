package mk.ukim.finki.wpaud.service.impl;

import mk.ukim.finki.wpaud.model.Category;
import mk.ukim.finki.wpaud.model.Color;
import mk.ukim.finki.wpaud.model.Manufacturer;
import mk.ukim.finki.wpaud.model.Product;
import mk.ukim.finki.wpaud.model.exceptions.CategoryNotFoundException;
import mk.ukim.finki.wpaud.model.exceptions.ManufacturerNotFoundException;
import mk.ukim.finki.wpaud.model.exceptions.ProductNotFoundException;
import mk.ukim.finki.wpaud.repository.jpa.ColorRepository;
import mk.ukim.finki.wpaud.service.ColorService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ColorServiceImpl implements ColorService {
    private final ColorRepository colorRepository;

    public ColorServiceImpl(ColorRepository colorRepository) {
        this.colorRepository = colorRepository;
    }

    @Override
    public Optional<Color> save(Color color) {
        return Optional.of(colorRepository.save(color));
    }
    @Override
    public List<Color> listColors() {
        return colorRepository.findAll();
    }

    @Override
    public Optional<Color> findById(Long id) {
        return colorRepository.findById(id);
    }

    @Override
    public Optional<Color> edit(Long id, Color color) {
        Color c = this.colorRepository.findById(id).orElseThrow(()
                -> new ProductNotFoundException(id));

        c.setName(color.getName());

        return Optional.of(this.colorRepository.save(c));
    }

    @Override
    public void deleteById(Long id) {
        colorRepository.deleteById(id);
    }
}