package mk.ukim.finki.wpaud.service;

import mk.ukim.finki.wpaud.model.Color;

import java.util.List;
import java.util.Optional;


public interface ColorService {
    Optional<Color> save(Color color);
    List<Color> listColors();
    Optional<Color> findById(Long id);
    Optional<Color> edit(Long id, Color color);
    void deleteById(Long id);
}
