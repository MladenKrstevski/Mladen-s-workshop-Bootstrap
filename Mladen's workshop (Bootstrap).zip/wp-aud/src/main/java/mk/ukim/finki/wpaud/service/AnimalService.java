package mk.ukim.finki.wpaud.service;

import mk.ukim.finki.wpaud.model.Animal;

import java.util.List;
import java.util.Optional;

public interface AnimalService {
    Animal create(String name);
    List<Animal> listAnimals();

    Optional<Animal> findById(Long id);
}
