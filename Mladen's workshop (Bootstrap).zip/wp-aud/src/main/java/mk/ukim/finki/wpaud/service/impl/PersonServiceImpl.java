package mk.ukim.finki.wpaud.service.impl;

import mk.ukim.finki.wpaud.model.Person;
import mk.ukim.finki.wpaud.model.exceptions.InvalidPersonArgumentException;
import mk.ukim.finki.wpaud.repository.impl.InMemoryPersonRepository;
import mk.ukim.finki.wpaud.service.PersonService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonServiceImpl implements PersonService {

    private final InMemoryPersonRepository inMemoryPersonRepository;

    public PersonServiceImpl(InMemoryPersonRepository inMemoryPersonRepository) {
        this.inMemoryPersonRepository = inMemoryPersonRepository;
    }

    @Override
    public Person create(String name, String lastname) {
        if(name == null || name.isEmpty() || lastname == null || lastname.isEmpty()) {
            throw new InvalidPersonArgumentException("You didn't enter a name and/or lastname.");
        }
        Person p = new Person(name, lastname);
        inMemoryPersonRepository.save(p);
        return p;
    }

    @Override
    public List<Person> listPersons() {
        return inMemoryPersonRepository.listPersons();
    }

    @Override
    public Optional<Person> findById(Long id) {
        return inMemoryPersonRepository.findById(id);
    }


}
