package mk.ukim.finki.wpaud.model.dto;

import java.time.LocalDateTime;

public class DiscountDto {
    private LocalDateTime validUntil;

    public DiscountDto() {
    }

    public DiscountDto(LocalDateTime validUntil) {
        this.validUntil = validUntil;
    }

    public LocalDateTime getValidUntil() {
        return validUntil;
    }

    public void setValidUntil(LocalDateTime validUntil) {
        this.validUntil = validUntil;
    }
}
