package mk.ukim.finki.wpaud.model.projections;

public interface UserProjection {
    String getUsername();
    String getName();
    String getSurname();
}
