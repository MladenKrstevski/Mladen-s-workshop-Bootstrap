package mk.ukim.finki.wpaud.model.exceptions;

public class InvalidUserCredentialsException extends RuntimeException {
    public InvalidUserCredentialsException() {
        super("Invalid user credential exception.");
    }
}
