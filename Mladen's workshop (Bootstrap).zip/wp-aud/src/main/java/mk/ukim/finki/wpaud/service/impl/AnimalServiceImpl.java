package mk.ukim.finki.wpaud.service.impl;

import mk.ukim.finki.wpaud.model.Animal;
import mk.ukim.finki.wpaud.repository.impl.InMemoryAnimalRepository;
import mk.ukim.finki.wpaud.service.AnimalService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnimalServiceImpl implements AnimalService {

    private final InMemoryAnimalRepository inMemoryAnimalRepository;

    public AnimalServiceImpl(InMemoryAnimalRepository inMemoryAnimalRepository) {
        this.inMemoryAnimalRepository = inMemoryAnimalRepository;
    }

    @Override
    public Animal create(String name) {
        Animal a = new Animal(name);
        return inMemoryAnimalRepository.save(a);
    }

    @Override
    public List<Animal> listAnimals() {
        return inMemoryAnimalRepository.findAll();
    }

    @Override
    public Optional<Animal> findById(Long id) {
        return inMemoryAnimalRepository.findById(id);
    }
}
