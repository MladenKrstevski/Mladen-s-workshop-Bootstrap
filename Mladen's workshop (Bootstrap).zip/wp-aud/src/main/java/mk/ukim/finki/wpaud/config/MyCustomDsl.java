package mk.ukim.finki.wpaud.config;

import mk.ukim.finki.wpaud.config.filters.JWTAuthenticationFilter;
import mk.ukim.finki.wpaud.config.filters.JWTAuthorizationFilter;
import mk.ukim.finki.wpaud.service.UserService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.password.PasswordEncoder;

public class MyCustomDsl extends AbstractHttpConfigurer<MyCustomDsl, HttpSecurity> {
    private final PasswordEncoder passwordEncoder;
    private final UserService userService;

    public MyCustomDsl(PasswordEncoder passwordEncoder, UserService userService) {
        this.passwordEncoder = passwordEncoder;
        this.userService = userService;
    }


    @Override
    public void configure(HttpSecurity http) throws Exception {
        AuthenticationManager authenticationManager = http.getSharedObject(AuthenticationManager.class);
        http.addFilter(new JWTAuthenticationFilter(authenticationManager, userService, passwordEncoder));
        http.addFilter(new JWTAuthorizationFilter(authenticationManager, userService));

    }


}
