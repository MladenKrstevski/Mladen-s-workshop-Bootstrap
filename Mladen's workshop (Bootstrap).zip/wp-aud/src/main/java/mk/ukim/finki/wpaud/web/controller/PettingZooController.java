package mk.ukim.finki.wpaud.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wpaud.model.Animal;
import mk.ukim.finki.wpaud.model.Person;
import mk.ukim.finki.wpaud.model.PettingZoo;
import mk.ukim.finki.wpaud.model.User;
import mk.ukim.finki.wpaud.service.PettingZooService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/pettingzoocontroller")
public class PettingZooController {

    private final PettingZooService pettingZooService;

    public PettingZooController(PettingZooService pettingZooService) {
        this.pettingZooService = pettingZooService;
    }

    @GetMapping
    public String getPettingZooPage(HttpServletRequest req, Model model) {
        return "pettingzoo";
    }
}
